import java.util.ArrayList;
import java.util.List;

public class Robo {

	static String roboName = "Robot0";
	static int currentCapacity = 0;
	static String lastNodeVisited = "City6";
	static String nextNodeToBeVisited = "City7";
	static int timeSinceLastCityLeft = 0;
	static String currentDestination = StringConst.INVENTORY;
	
	static List<TSPRequest> listCurrentRequests = new ArrayList<TSPRequest>();
	static List<String> currentFollowingPath = new ArrayList<String>();
}
