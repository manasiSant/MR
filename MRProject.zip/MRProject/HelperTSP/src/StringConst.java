
public class StringConst {
	public static String  STR_REQUEST="REQUESTROBOT";
	//public static String  STR_ACK="ACKNOWLEDGEMENT";
	public static String  STR_REQUEST_FULLFILLED="REQUEST_FULLFILLED";
	public static String  STR_SEEK_DEMAND="SEEKDEMAND";
	public static String  STR_REQUEST_SPERARTOR = "#";
	public static String  STR_SPERARTOR_COLON = ":";
	public static String  STR_SPERARTOR_PERCENT = "%";
	//public static String  STR_INFO_SEEK_DEMAND = "INFO_SEEK_DEMAND";
	public static String  NO_ACTION = "NA";
	public static String  LEFT = "L";
	public static String  RIGHT = "R";
	public static String  STRAIGHT = "S";
	public static String  UTURN = "U";
	public static int INT_MAX_ROBO_CAP = 100;
	public static String INVENTORY = "ColdStorage";
	public static String  STR_SECONDARYACK="SECACKNOWLEDGEMENT";
	public static String  STR_ACK_CITY="ACKNOWLEDGEMENT_CITY";
	public static String  STR_INFO_FROM_CITY_ROBO_REACHED="INFO_CITY_ROBO_REACHED";
	public static String  STR_ACK_ROBOT="ACKNOWLEDGEMENT_ROBOT";
	public static String  STR_SEEK_DEMAND_REPLY="SEEKDEMAND_REPLY";
	public static String  STR_STATUS_CHANGE="STATUS_CHANGE";
}
